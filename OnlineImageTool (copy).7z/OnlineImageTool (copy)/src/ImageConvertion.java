

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;

/**
 * Servlet implementation class UploadServlet
 */
@WebServlet("/ImageConvertion")
public class ImageConvertion extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public ImageConvertion() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String format=request.getParameter("format");
		System.out.println(format);
		File dir = new File("/home/akshaya/eclipse-workspace/OnlineImageTool/pic/");
		String[] files = dir.list();
		System.out.println(files.length);
		FileInputStream inputStream = new FileInputStream("/home/akshaya/eclipse-workspace/OnlineImageTool/pic/"+files[0]);
        FileOutputStream outputStream = new FileOutputStream("/home/akshaya/eclipse-workspace/OnlineImageTool//pic/output."+format.toLowerCase());
        BufferedImage inputImage = ImageIO.read(inputStream);
        boolean result = ImageIO.write(inputImage, format, outputStream);
        outputStream.close();
        inputStream.close();
         
        request.getRequestDispatcher("/result.html").forward(request, response);
	}

}
