

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.oreilly.servlet.MultipartRequest;

/**
 * Servlet implementation class UploadServletnew
 */
@WebServlet("/UploadServletnew")
@MultipartConfig(fileSizeThreshold=1024*1024*2, // 2MB
maxFileSize=1024*1024*10,      // 10MB
maxRequestSize=1024*1024*50)
public class UploadServletnew extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String UPLOAD_DIRECTORY="/home/akshaya/eclipse-workspace/OnlineImageTool/pic";
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UploadServletnew() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");  
		PrintWriter out = response.getWriter();  
		File fileSaveDir=new File("/");
		for (Part part : request.getParts()) {
			System.out.println("Part"+part);
		}
		Part part=request.getPart("fileName");
		
        String fileName=extractFileName(part);
        if(fileName.isEmpty()) {
			   out.println("<script type=\"text/javascript\">");
			   out.println("alert('Upload a file');");
			   out.println("location='compress.jsp';");
			   out.println("</script>");
		}
        part.write(UPLOAD_DIRECTORY + File.separator + fileName); 
		out.print("successfully uploaded");  
		
		request.getRequestDispatcher("/compression.jsp").forward(request, response);
	}
	private String extractFileName(Part part) {
	    String contentDisp = part.getHeader("content-disposition");
	    String[] items = contentDisp.split(";");
	    for (String s : items) {
	        if (s.trim().startsWith("filename")) {
	            return s.substring(s.indexOf("=") + 2, s.length()-1);
	        }
	    }
	    return "";
	}
}
