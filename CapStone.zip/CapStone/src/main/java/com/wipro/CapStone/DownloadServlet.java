package com.wipro.CapStone;


import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DownloadServlet
 */
@WebServlet("/DownloadServlet")
public class DownloadServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String filepath = "/home/akshaya/eclipse-workspace/atm/CapStone/picture/";
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DownloadServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		File dir = new File(filepath);
		String[] files = dir.list();
		String filename="";
		for(String file:files) {
			if(file.startsWith("output")) {
				filename=file;
				break;
			}
		}
		String extension = filename.substring(files[0].lastIndexOf("."));
		extension=extension.substring(1);
		
		PrintWriter out = response.getWriter();
		
		switch(extension) {
		
		case "jpeg":response.setContentType("image/jpeg");
				break;
		case "jpg":response.setContentType("image/jpg");
		break;
		case "png":response.setContentType("image/png");
		break;
		case "gif":response.setContentType("image/gif");
		break;
}	

		
		
		response.setHeader("Content-Disposition", "attachment; filename=\""
		        + filename + "\"");

		FileInputStream fileInputStream = new FileInputStream(filepath
		        + filename);

		int i;
		while( (i = fileInputStream.read()) != -1 )
		{
			out.write(i);
		}
		fileInputStream.close();
		out.close();
		
		for(String file:files) {
			File file1=new File(filepath+"/"+file);
			file1.delete();
			
		}
	
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
