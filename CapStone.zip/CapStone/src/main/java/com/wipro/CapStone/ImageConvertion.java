
package com.wipro.CapStone;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



/**
 * Servlet implementation class UploadServlet
 */
@WebServlet("/ImageConvertion")
public class ImageConvertion extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String filename="/home/akshaya/eclipse-workspace/atm/CapStone/picture/";

    /**
     * Default constructor. 
     */
    public ImageConvertion() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String format=request.getParameter("format");
		File dir = new File(filename);
		String[] files = dir.list();
		FileInputStream inputStream = new FileInputStream(filename+files[0]);
        FileOutputStream outputStream = new FileOutputStream(filename+"output."+format.toLowerCase());
        BufferedImage inputImage = ImageIO.read(inputStream);
        boolean result = ImageIO.write(inputImage, format, outputStream);
        outputStream.close();
        inputStream.close();
         
        request.getRequestDispatcher("result.html").forward(request, response);
	}

}
