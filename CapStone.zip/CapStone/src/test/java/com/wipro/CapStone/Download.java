package com.wipro.CapStone;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Download {
WebDriver driver;
	
	@FindBy(id="download")
	WebElement download;
	
	
	
	public Download(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	public String downloadButton() {
		download.click();
		return download.getText();
				
	}
	
}
