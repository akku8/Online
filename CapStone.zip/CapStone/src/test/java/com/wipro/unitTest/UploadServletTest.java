package com.wipro.unitTest;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.mockito.Mock;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import javax.servlet.http.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import com.wipro.CapStone.UploadServlet;





public class UploadServletTest extends Mockito{
	String filepath = "picture";
	File target = new File(filepath);
	File source= new File("resources/output.jpg");
	@Mock
	 HttpServletRequest request;
	 @Mock
	 HttpServletResponse response;
	 @Mock
	 RequestDispatcher rd;
	 @Before
	 public void setUp() throws Exception {
	  MockitoAnnotations.initMocks(this);
	 clean_folder();
	 }

  
	@Test
    public void uploadServlet() throws Exception {
		 Part mockPart = mock(Part.class);
		 when(request.getPart("fileName")).thenReturn(mockPart);
       new UploadServlet().doPost(request, response);
     
    }
    @After
    public void clean() {
    	clean_folder();
    }
    public void clean_folder() {
        String files[]=target.list();
        for(String file:files) {
			File file1=new File(target+"/"+file);
			file1.delete();}
    }
    }

