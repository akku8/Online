
package com.wipro.CapStone;



import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;

import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import javax.imageio.stream.ImageOutputStream;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class UploadServlet
 */
@WebServlet("/ImageCompression")
public class ImageCompression extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String filename="/home/akshaya/eclipse-workspace/atm/CapStone/picture/";

    /**
     * Default constructor. 
     */
    public ImageCompression() {
        // TODO Auto-generated constructor stub
    }
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		float quality=Float.parseFloat(request.getParameter("quality"));
		File dir = new File(filename);
		String[] files = dir.list();
		String extension = files[0].substring(files[0].lastIndexOf("."));
		extension=extension.substring(1);
		FileInputStream inputStream = new FileInputStream(filename+files[0]);
        FileOutputStream outputStream = new FileOutputStream(filename+"output."+extension);
        BufferedImage image = ImageIO.read(inputStream);
       
        Iterator<ImageWriter> writers = ImageIO.getImageWritersByFormatName(extension);
        if (!writers.hasNext())
			throw new IllegalStateException("No writers found");

		ImageWriter writer = (ImageWriter) writers.next();
		ImageOutputStream ios = ImageIO.createImageOutputStream(outputStream);
		writer.setOutput(ios);
		ImageWriteParam param = writer.getDefaultWriteParam();
		param.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
		param.setCompressionQuality(quality);
		writer.write(null, new IIOImage(image, null, null), param);
        outputStream.close();
        inputStream.close();
        ios.close();
        writer.dispose();
         
        request.getRequestDispatcher("result.html").forward(request, response);
	}

}
