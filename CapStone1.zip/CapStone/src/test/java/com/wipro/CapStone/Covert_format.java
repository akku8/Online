package com.wipro.CapStone;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class Covert_format {
	WebDriver driver;
	
	@FindBy(id="format")
	WebElement format;
	
	@FindBy(id="submit")
	WebElement submit;
	
	
	public Covert_format(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	public String selectFormat() {
		Select fmt=new Select(format);
		fmt.selectByIndex(2);
		submit.click();
		return driver.getTitle();
		
	}

}
