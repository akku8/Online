package com.wipro.CapStone;

import static org.junit.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;

public class ApplicationTest{
	
	String driverpath="resources/geckodriver";
	WebDriver driver;
	HomePage homepage;
	Compress_Upload compressdriver;
	Convert_Upload convertdriver;
	Covert_format format;
	Compress_Quality quality;
	Download download;
	String title;
	
	

	@Before
	public  void setup() {

		FirefoxBinary firefoxBinary = new FirefoxBinary();
        firefoxBinary.addCommandLineOptions("--headless");
        System.setProperty("webdriver.gecko.driver", driverpath);
        FirefoxOptions firefoxOptions = new FirefoxOptions();
        firefoxOptions.setBinary(firefoxBinary);
        driver = new FirefoxDriver(firefoxOptions);   
        driver.get("http://localhost:8080/CapStone-0.0.1-SNAPSHOT/");
	}
	
	@Test
	public void compressFlowWithOutFile() {
		
		homepage=new HomePage(driver);
		title=homepage.getHomeTitle();
		assertTrue(title.contains("Welcome to Online Image Tools"));
		
		title=homepage.getCompressButtonTitle();
		assertTrue(title.contains("Compression"));
		
		compressdriver=new Compress_Upload(driver);
		title=compressdriver.noFileCheck();
		assertTrue(title.contains("Upload a file"));

		}
	
	@Test
		public void compressFlowWithWrongFile() {
			
			homepage=new HomePage(driver);
			title=homepage.getHomeTitle();
			assertTrue(title.contains("Welcome to Online Image Tools"));
			
			title=homepage.getCompressButtonTitle();
			assertTrue(title.contains("Compression"));
			
			compressdriver=new Compress_Upload(driver);
			title=compressdriver.wrongFileCheck();
			assertTrue(title.contains("Invalid file type"));
			
			}
	
	@Test
	public void compressFlowWithWithFileInvalidQuality() {
		
		homepage=new HomePage(driver);
		title=homepage.getHomeTitle();
		assertTrue(title.contains("Welcome to Online Image Tools"));
		
		title=homepage.getCompressButtonTitle();
		assertTrue(title.contains("Compression"));
		
		compressdriver=new Compress_Upload(driver);
		title=compressdriver.fileCheck();
		assertTrue(title.contains("Compression of Image"));
		
		quality=new Compress_Quality(driver);
		title=quality.setQualityAboveLimit();
		assertTrue(title.contains("Invalid value for quality"));
		

		}
	
	@Test
	public void compressFlowWithGoodQualityFile() {
		
		homepage=new HomePage(driver);
		title=homepage.getHomeTitle();
		assertTrue(title.contains("Welcome to Online Image Tools"));
		
		title=homepage.getCompressButtonTitle();
		assertTrue(title.contains("Compression"));
		
		compressdriver=new Compress_Upload(driver);
		title=compressdriver.fileCheck();
		assertTrue(title.contains("Compression of Image"));
		
		quality=new Compress_Quality(driver);
		title=quality.setQualityOnLimit();
		assertTrue(title.contains("Download Image"));
		
		download= new Download(driver);
		title=download.downloadButton();
		assertTrue(title.contains("Click here to download"));
		
		

		}
	
	
	@Test
	public void convertFlowWithOutFile() {
		
		homepage=new HomePage(driver);
		title=homepage.getHomeTitle();
		assertTrue(title.contains("Welcome to Online Image Tools"));
		
		title=homepage.getConvertButtonTitle();
		assertTrue(title.contains("Convertion"));
		
		convertdriver=new Convert_Upload(driver);
		title=convertdriver.noFileCheck();
		assertTrue(title.contains("Upload a file"));

		}
	
	@Test
	public void convertFlowWithWrongFile() {
		
		homepage=new HomePage(driver);
		title=homepage.getHomeTitle();
		assertTrue(title.contains("Welcome to Online Image Tools"));
		
		title=homepage.getConvertButtonTitle();
		assertTrue(title.contains("Convertion"));
		
		convertdriver=new Convert_Upload(driver);
		title=convertdriver.wrongFileCheck();
		assertTrue(title.contains("Invalid file type"));
				

		}
	
	@Test
	public void convertFlowWithGoodFile() {
		
		homepage=new HomePage(driver);
		title=homepage.getHomeTitle();
		assertTrue(title.contains("Welcome to Online Image Tools"));
		
		title=homepage.getConvertButtonTitle();
		assertTrue(title.contains("Convertion"));
		
		convertdriver=new Convert_Upload(driver);
		title=convertdriver.FileCheck();
		assertTrue(title.contains("Convertion of Image"));
		
		format=new Covert_format(driver);
		title=format.selectFormat();
		assertTrue(title.contains("Download Image"));
		
		download= new Download(driver);
		title=download.downloadButton();
		assertTrue(title.contains("Click here to download"));
		

		}
	
	@After
	public void cleanUp() {
	 driver.quit();
	}
	
}