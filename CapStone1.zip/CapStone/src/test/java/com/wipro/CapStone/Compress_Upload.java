package com.wipro.CapStone;
import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Compress_Upload {
	WebDriver driver;
	String wrongfile="/home/akshaya/eclipse-workspace/atm/CapStone/resources/new.java";
	String correctfile="/home/akshaya/eclipse-workspace/atm/CapStone/resources/index.jpg";
	
	@FindBy(xpath=".//button")
	WebElement upload;
	
	@FindBy(id="file")
	WebElement file;
	
	
	public Compress_Upload(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	public String noFileCheck() {
		upload.click();
		Alert alert = driver.switchTo().alert();
		String title=alert.getText();
		alert.accept();
		return title;				
	}
	
	
	public String wrongFileCheck() {
		file.sendKeys(wrongfile);
		Alert alert = driver.switchTo().alert();
		String title=alert.getText();
		alert.accept();
		return title;
	}
	
	public String fileCheck() {
		file.sendKeys(correctfile);
		upload.click();
		return driver.getTitle();
	}
}
