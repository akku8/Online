package com.wipro.CapStone;
import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Compress_Quality {
WebDriver driver;
	
	@FindBy(id="quality")
	WebElement quality;
	
	@FindBy(xpath=".//button")
	WebElement submit;
	
	
	public Compress_Quality(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	public String setQualityAboveLimit() {
		quality.sendKeys("2");
		submit.click();
		Alert alert=driver.switchTo().alert();
		String title=alert.getText();
		alert.accept();
		return title;
	}
	
	
	
	public String setQualityOnLimit() {
		quality.sendKeys("0.7");
		submit.click();
		return driver.getTitle();
	}
	
	
}
