package com.wipro.CapStone;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage {
	WebDriver driver;
	
	@FindBy(xpath=".//h1")
	WebElement homeTitle;
	
	@FindBy(id="compress")
	WebElement compress_button;
	
	@FindBy(id="convert")
	WebElement convert_button;
	
	public HomePage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	public String getHomeTitle(){
		return homeTitle.getText();
	}
	
	public String getCompressButtonTitle() {
		compress_button.click();
		return driver.getTitle();
	}
	
	public String getConvertButtonTitle() {
		convert_button.click();
		return driver.getTitle();
	}
	
	public void clickCompress() {
		compress_button.click();
	}
	
	public void clickConvert() {
		convert_button.click();
	}
}
