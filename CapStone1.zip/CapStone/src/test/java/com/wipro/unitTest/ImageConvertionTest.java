package com.wipro.unitTest;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.mockito.Mock;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.wipro.CapStone.ImageConvertion;





public class ImageConvertionTest extends Mockito{
	String filepath = "picture";
	File target = new File(filepath);
	File source= new File("resources/index.jpg");
	@Mock
	 HttpServletRequest request;
	 @Mock
	 HttpServletResponse response;
	 @Mock
	 RequestDispatcher rd;
	 @Before
	 public void setUp() throws Exception {
	  MockitoAnnotations.initMocks(this);
	  clean_folder();
	 }

    @Test
    public void imageConvertion() throws Exception {
        when(request.getParameter("format")).thenReturn("gif");
        when(request.getRequestDispatcher("result.html")).thenReturn(rd);     
        Path tempFile = Files.createTempFile("index", ".jpg");
        if (target.isDirectory()) {
        	String files[]=target.list();
           if (files.length<= 0) {
        	  
        	   Files.copy(source.toPath(),Paths.get("picture/"+tempFile.getFileName()),StandardCopyOption.COPY_ATTRIBUTES);  
        	   
           }
        }
        new ImageConvertion().doPost(request, response);
     
        verify(rd).forward(request, response);   
        
    }
    @After
    public void clean() {
    	clean_folder();
    }
    public void clean_folder() {
        String files[]=target.list();
        for(String file:files) {
			File file1=new File(target+"/"+file);
			file1.delete();}
    }
    }

